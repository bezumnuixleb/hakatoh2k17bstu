<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Level1" tilewidth="80" tileheight="80" tilecount="6" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="80" height="80" source="../../textures/world/level1nabor/1.png"/>
 </tile>
 <tile id="1">
  <image width="80" height="80" source="../../textures/world/level1nabor/2.png"/>
 </tile>
 <tile id="2">
  <image width="80" height="80" source="../../textures/world/level1nabor/3.png"/>
 </tile>
 <tile id="3">
  <image width="80" height="80" source="../../textures/world/level1nabor/4.png"/>
 </tile>
 <tile id="4">
  <image width="80" height="80" source="../../textures/world/level1nabor/5.png"/>
 </tile>
 <tile id="5">
  <image width="80" height="80" source="../../textures/world/level1nabor/6.png"/>
 </tile>
</tileset>
