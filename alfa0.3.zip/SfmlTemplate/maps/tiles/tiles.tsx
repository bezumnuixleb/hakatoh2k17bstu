<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Dcp1" tilewidth="80" tileheight="80" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="80" height="80" source="../../textures/world/tiles/air.png"/>
 </tile>
 <tile id="2">
  <image width="80" height="80" source="../../textures/world/tiles/lava.png"/>
  <objectgroup draworder="index">
   <object id="1" x="1" y="0" width="80" height="79"/>
  </objectgroup>
 </tile>
 <tile id="3">
  <image width="80" height="80" source="../../textures/world/tiles/stone.png"/>
  <objectgroup draworder="index">
   <object id="1" x="-1" y="2" width="82" height="75"/>
  </objectgroup>
 </tile>
 <tile id="4">
  <image width="80" height="80" source="../../textures/world/tiles/sun.png"/>
 </tile>
 <tile id="5">
  <image width="80" height="80" source="../../textures/world/tiles/travka.png"/>
  <objectgroup draworder="index">
   <object id="1" x="1" y="5" width="78" height="73"/>
  </objectgroup>
 </tile>
</tileset>
