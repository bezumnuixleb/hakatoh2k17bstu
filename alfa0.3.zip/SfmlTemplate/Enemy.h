#pragma once
#include "Platform.h"

struct tosaveEnemy {
	bool alife, ismove, onground;
	float speed, w, h, dx, dy, x, y;
	int moveTimer;
	float shottimer;
	int type;
	float anim;
};
class Enemy
{
public:
	


	Enemy();
	~Enemy();

	Sprite sprite;
	IntRect posintexture;
	tosaveEnemy core;

	Enemy(Texture*maintext, int Type, float X, float Y, int W, int H);
	Enemy(Sprite& sprite, int Type, float X, float Y, int W, int H,float speed);
	const Sprite& show();

	void CollisionforEnemys(int type,float Dx, float Dy, vector<Platform>&);
	void updateMobs(float px,float py,float time, vector<Platform>&plat, vector<Enemy>&shots);
	void updateShots(float px, float py, float time, vector<Platform>&plat);
};

