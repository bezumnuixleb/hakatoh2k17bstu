#include "Menu.h"


using namespace sf;
int main()
{

	RenderWindow window(sf::VideoMode(1280, 720), "HEDGEHOG");
	vector<Tile> tiles, tilesnocollis;
	vector<Platform> Plat , Dmg;
	View view;
	view.reset(sf::FloatRect(0, 0, 1280, 720));

	vector<Enemy> mobs,shots;
	Level level;
	Texture maintext;
	maintext.loadFromFile("textures/world/maintext.png");
	Clock clock;	
	Player hedgehog;
	
	bool levelisrun = false;
	
	while (window.isOpen())
	{
		if (levelisrun == false) {
			menu(window);
			//menu i td
			//...
			//vibor yrovnya
			//case 1:{
			level.LoadFromFile(mobs,
				"maps/level1.tmx", 
				&maintext,0,
				&hedgehog,
				tiles, tilesnocollis, Plat, Dmg);
		
			//level.LoadFromFile("maps/test.tmx",&maintext, tiles, tilesnocollis,&hedgehog,mobs);
			levelisrun = true;
			//}break;
		}
		else
		{//igrovoi process
			float time = clock.getElapsedTime().asMicroseconds();
			clock.restart();
			time = time / 800;

			sf::Event event;
			while (window.pollEvent(event))
			{
				if (event.type == sf::Event::Closed)
					window.close();
				if (Keyboard::isKeyPressed(Keyboard::Escape))
				{
					Vector2f tmp = view.getCenter();
					pause(window,tmp.x,tmp.y);
				}
				if (event.type == sf::Event::KeyReleased)
				{
					if (event.key.code == Keyboard::Right) {
						hedgehog.stop();
						hedgehog.speed = 0;
						hedgehog.ismove = false;
					}

					if (event.key.code == Keyboard::Left) {
						hedgehog.stop();
						hedgehog.speed = 0;
						hedgehog.ismove = false;
					}
				}
			}
			
			hedgehog.update(time, Plat, Dmg,mobs,shots);
			for (int i = 0; i < mobs.size(); i++)
			{
				mobs[i].updateMobs(hedgehog.x,hedgehog.y,time, Plat,shots);
			}
			for (int i = 0; i < shots.size(); i++)
			{
				shots[i].updateShots(hedgehog.x, hedgehog.y, time, Plat);
			}
			if (hedgehog.x + 100 < 640) {
				view.setCenter(640, 360);
			}
			else
			{
				if (hedgehog.x + 100 > level.width * 80 - 640) {
					view.setCenter(level.width*80-640, 360);
				}
				else
				{
					view.setCenter(hedgehog.x + 100, 360);

				}
			}
			window.setView(view);
			
			window.clear();
			for (int i = 0; i < tilesnocollis.size(); i++)
			{
				window.draw(tilesnocollis[i].show());
			}
			for (int i = 0; i < tiles.size(); i++)
			{
				window.draw(tiles[i].show());
			}
			for (int i = 0; i < mobs.size(); i++)
			{
				window.draw(mobs[i].show()); 
			}
			for (int i = 0; i < shots.size(); i++)
			{if(shots[i].core.alife==true)
				window.draw(shots[i].show());
			}
			window.draw(hedgehog.show());

		}
		window.display();
	}

	return 0;
}