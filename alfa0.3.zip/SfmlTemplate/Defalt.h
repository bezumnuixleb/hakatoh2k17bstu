#pragma once

#include "Add.h"
using namespace sf;
using namespace std;
class Defalt
{
protected:
	forrend data;
	
public:
	Defalt();
	Defalt(string,float,float,float,float);
	const Sprite& show();
	~Defalt();
};

