#pragma once
#include "Level.h"
void menu(RenderWindow & window);
void pause(RenderWindow & window,float,float);
void death(RenderWindow & window, float, float);