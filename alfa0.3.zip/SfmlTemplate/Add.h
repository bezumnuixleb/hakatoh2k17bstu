#include <SFML/Graphics.hpp>
#include <iostream>
#include <deque>
#include <vector>
#include <list>
#include "TinyXML/tinyxml.h"

using namespace sf;
using namespace std;

struct forrend {
	Texture texture;
	Sprite sprite;
	FloatRect posinworld ; 
	IntRect posintexture;
};
