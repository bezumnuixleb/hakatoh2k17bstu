#include "Enemy.h"



Enemy::Enemy(Texture*maintext, int Type, float X, float Y, int W, int H)
{
	
		core.x = X; core.y = Y; core.w = W; core.h = H; core.type = Type; core.moveTimer = 0;
		core.speed = 0; core.dx = 0; core.dy = 0; core.shottimer = 0;
		core.alife = true; core.onground = false; core.ismove = false;
		sprite.setTexture(*maintext);
		switch (Type)
		{
		case 0: {//p4ela
			posintexture = { 0,800,80,80 };
			core.dx = 0.1;

		}break;
		default:
			break;
		}
		sprite.setTextureRect(posintexture);

}
Enemy::Enemy(Sprite & spritenew, int Type, float X, float Y, int W, int H, float speed)
{

	core.x = X; core.y = Y; core.w = W; core.h = H; core.type = Type; core.moveTimer = 0;
	core.speed = 0; core.dx = 0; core.dy = 0;core.shottimer = 0;
	core.alife = true; core.onground = false; core.ismove = false;
	sprite.setTexture(*spritenew.getTexture());
	switch (Type)
	{
	case 21: {//pulya
		if (speed > 0) {
			posintexture = { 0,1600,20,20 };
		}
		else
		{
			posintexture = {20,1600,20,20 };
		}
		core.dx = speed;

	}break;
	default:
		break;
	}
}
Enemy::Enemy()
{
}

Enemy::~Enemy()
{
}

void  Enemy::CollisionforEnemys(int type,float Dx, float Dy, vector<Platform>&plat) {
	FloatRect temp = { core.x,core.y,core.w,core.w };
	
		for (int i = 0; i < plat.size(); i++)
		{
			if (plat[i].pos.intersects(temp)) {
				if (type == 0) {
					if (Dy > 0)
					{
						core.y = plat[i].pos.top - core.h;  core.dy = 0;  core.onground = true;
					}
					if (Dy < 0) { core.y = plat[i].pos.top + plat[i].pos.height;   core.dy = 0; }
					if (Dx > 0) {
						core.x = plat[i].pos.left - core.w; core.dx *= -1; core.moveTimer = 0;
					}
					if (Dx < 0) {
						core.x = plat[i].pos.left + plat[i].pos.width; core.dx *= -1; core.moveTimer = 0;
					}
				}
				if (type == 21) {
					if (Dy > 0)
					{
						core.alife = false; core.dx = 0;
					}
					if (Dy < 0) { core.alife = false; core.dx = 0; }
					if (Dx > 0) {
						core.alife = false; core.dx = 0;
					}
					if (Dx < 0) {
						core.alife = false; core.dx = 0;
					}
				}
				
			}
		}
	

}
void Enemy::updateMobs(float px, float py, float time, vector<Platform>&plat,vector<Enemy>&shots)
{
	if (core.type == 0) {//p4ela

		core.moveTimer += time; if (core.moveTimer>3000) { core.dx *= -1; core.moveTimer = 0; }
		core.shottimer += time;
		CollisionforEnemys(core.type,core.dx, 0, plat);
		core.x += core.dx*time;
		sprite.setPosition(core.x, core.y); 
		if (core.shottimer > 2000) {
			if (core.dx > 0) {
				core.shottimer = 0;
				Enemy tmpmob(sprite, 21, core.x+30, core.y+30, 20, 20, 0.4);
				shots.push_back(tmpmob);
			}
			else {
				core.shottimer = 0;
				Enemy tmpmob(sprite,21, core.x+40, core.y+30, 20, 20, -0.4);
				shots.push_back(tmpmob);
			}
		}
		if (core.dx > 0) {
			posintexture = { 80,800,80,80 };
			sprite.setTextureRect(posintexture);
		}
		else
		{
			posintexture = { 0,800,80,80 };
			sprite.setTextureRect(posintexture);
		}

	}
}
void Enemy::updateShots(float px, float py, float time, vector<Platform>&plat)
{
	if (core.type == 21) {//shots
		core.moveTimer += time; if (core.moveTimer>4000){ core.alife = false; core.dx = 0; }
		CollisionforEnemys(core.type, core.dx, 0, plat);
		core.x += core.dx*time; if (core.dx > 0) {
			sprite.setTextureRect(posintexture);
		}
		else
		{
			sprite.setTextureRect(posintexture);
		}
		sprite.setPosition(core.x, core.y);
		
	}
}
const Sprite& Enemy::show() {
	
		return sprite;
	
}