#include "Menu.h"
void menu(RenderWindow & window)
{
	Texture menuTexture1, menuTexture2, menuTexture3, menuBackground, menuTexture1T, menuTexture2T, menuTexture3T;
	menuTexture1.loadFromFile("images/1.png");//play
	menuTexture2.loadFromFile("images/2.png");//�����
	menuTexture3.loadFromFile("images/3.png");//lvl

	menuTexture1T.loadFromFile("images/11.png");
	menuTexture2T.loadFromFile("images/22.png");
	menuTexture3T.loadFromFile("images/33.png");

	menuBackground.loadFromFile("images/fon.jpg");	
	Sprite menu1(menuTexture1), menu2(menuTexture2), menu3(menuTexture3), menu1T(menuTexture1T), menu2T(menuTexture2T), menu3T(menuTexture3T), menuBg(menuBackground);
	bool isMenu = 1;
	int menuNum = 0;
	


	menu1.setPosition(380, 30);
	menu2.setPosition(380, 230);
	menu3.setPosition(380, 430);

	menu1T.setPosition(380, 30);
	menu2T.setPosition(380, 230);
	menu3T.setPosition(380, 430);

	menuBg.setPosition(0, 0);

	//////////////////////////////����///////////////////
	while (isMenu)
	{
		window.clear();

		window.draw(menuBg);
		window.draw(menu1);
		window.draw(menu2);
		window.draw(menu3);

		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (Keyboard::isKeyPressed(Keyboard::Escape))
			{
				window.close();
			}
		}
		menuNum = 0;
		if (IntRect(380, 30, 500, 150).contains(Mouse::getPosition(window))) { window.draw(menu1T); menuNum = 1; }
		if (IntRect(380, 230, 500, 150).contains(Mouse::getPosition(window))) { window.draw(menu2T); menuNum = 2; }
		if (IntRect(380, 430, 500, 150).contains(Mouse::getPosition(window))) { window.draw(menu3T); menuNum = 3; }

		if (Mouse::isButtonPressed(Mouse::Left))
		{
			if (menuNum == 1) { isMenu = false; }//���� ������ ������ ������, �� ������� �� ���� 
			if (menuNum == 2) { }
			if (menuNum == 3) { window.close(); isMenu = false; }

		}
		window.display();
	}
	////////////////////////////////////////////////////
}
void pause(RenderWindow & window, float x, float y)
{
	Texture pauseTexture1, pauseTexture2, pauseTexture1T, pauseTexture2T, pause, pauseFON;

	pauseTexture1.loadFromFile("images/pause1.png");//play
	pauseTexture2.loadFromFile("images/pause2.png");//�����

	pauseTexture1T.loadFromFile("images/pause11.png");
	pauseTexture2T.loadFromFile("images/pause22.png");

	pause.loadFromFile("images/pause.png");
	pauseFON.loadFromFile("images/pauseFON.png");//play

	Sprite pause1(pauseTexture1), pause2(pauseTexture2), pause1T(pauseTexture1T), pause2T(pauseTexture2T), PAUSE(pause), pauseFon(pauseFON);
	bool isMenu = 1;
	int menuNum = 0;

	pause1.setPosition(x-640+80, 200);
	pause2.setPosition(x - 640 + 80, 400);

	pause1T.setPosition(x - 640 + 80, 200);
	pause2T.setPosition(x - 640 + 80, 400);

	PAUSE.setPosition(x - 640 + 130, 30);
	//pauseFon.setPosition(0, 0);
	//pauseFon.setColor(sf::Color(255, 255, 255, 128));
	//////////////////////////////����///////////////////

	//window.draw(pauseFon);
	while (isMenu)
	{
		//window.clear();
		window.draw(PAUSE);
		window.draw(pause1);
		window.draw(pause2);

		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}
		menuNum = 0;
	
		if (IntRect(80,200, 500, 150).contains((Mouse::getPosition(window)))) { window.draw(pause1T); menuNum = 1; }
		if (IntRect(80, 400, 500, 150).contains(Mouse::getPosition(window))) { window.draw(pause2T); menuNum = 2; }

		if (Mouse::isButtonPressed(Mouse::Left))
		{
			if (menuNum == 1) { isMenu = false; }//���� ������ ������ ������, �� ������� �� ���� 
			if (menuNum == 2) { window.close(); isMenu = false; }

		}
		window.display();
	}
	////////////////////////////////////////////////////
}
void death(RenderWindow & window, float x, float y)
{
	Texture menuTexture1, menuTexture2, menuBackground, menuTexture1T, menuTexture2T;

	menuTexture1.loadFromFile("images/Menu.png");//Menu
	menuTexture2.loadFromFile("images/Exit.png");//�����

	menuTexture1T.loadFromFile("images/Menu1.png");
	menuTexture2T.loadFromFile("images/Exit1.png");

	menuBackground.loadFromFile("images/End.jpg");
	Sprite menu1(menuTexture1), menu2(menuTexture2), menu1T(menuTexture1T), menu2T(menuTexture2T), menuBg(menuBackground);
	bool isMenu = 1;
	int menuNum = 0;



	menu1.setPosition(x - 640 + 380, 30);
	menu2.setPosition(x - 640 + 380, 230);

	menu1T.setPosition(x - 640 + 380, 30);
	menu2T.setPosition(x - 640 + 380, 230);

	menuBg.setPosition(x - 640, 0);

	//////////////////////////////����///////////////////
	while (isMenu)
	{
		window.clear();

		window.draw(menuBg);
		window.draw(menu1);
		window.draw(menu2);
		sf::Event event;

		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
			if (Keyboard::isKeyPressed(Keyboard::Escape))
			{
				window.close();
			}
		}
		menuNum = 0;
		if (IntRect(380, 30, 500, 150).contains(Mouse::getPosition(window))) { window.draw(menu1T); menuNum = 1; }
		if (IntRect(380, 230, 500, 150).contains(Mouse::getPosition(window))) { window.draw(menu2T); menuNum = 2; }

		if (Mouse::isButtonPressed(Mouse::Left))
		{
			if (menuNum == 1) { isMenu = false; }//���� ������ ������ ������, �� ������� �� ���� 
			if (menuNum == 2) { window.close(); isMenu = false; }

		}
		window.display();
	}
	////////////////////////////////////////////////////
}